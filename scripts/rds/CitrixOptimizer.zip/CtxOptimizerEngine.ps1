﻿<#
.SYNOPSIS
    Citrix Optimization Engine helps to optimize operating system to run better with XenApp or XenDesktop solutions. 

.DESCRIPTION
    Citrix Optimization Engine helps to optimize operating system to run better with XenApp or XenDesktop solutions. This script can run in three different modes - Analyze, Execute and Rollback. Each execution will automatically generate an XML file with a list of performed actions (stored under .\Logs folder) that can be used to rollback the changes applied. 

.PARAMETER Source
    Source XML file that contains the required configuration. Typically located under .\Templates folder. This file provides instructions that CTXOE can process. 

.PARAMETER Mode
    CTXOE supports three different modes: 
        Analyze - Do not apply any changes, only show the recommended changes. 
        Execute - Apply the changes to the operating system. 
        Rollback - Revert the applied changes. Requires a valid XML backup from the previously run Execute phase. 

.PARAMETER Groups
    Array that allows you to specify which groups to process from a specified source file. 

.PARAMETER OutputXml
    The location where the output XML should be saved. The XML with results is automatically saved under .\Logs folder, but you can optionally specify also other location. This argument can be used together with -OutputHtml.

.PARAMETER OutputHtml
    The location where the output HTML report should be saved. The HTML with results is automatically saved under .\Logs folder, but you can optionally specify another location. This argument can be used together with -OutputXml.

.PARAMETER OptimizerUI
    Parameter used by Citrix Optimizer UI to retrieve information from optimization engine. For internal use only. 
	
.EXAMPLE
    .\CtxOptimizerEngine.ps1 -Source C:\Temp\Win10.xml -Mode Analyze
    Process all entries in Win10.xml file and display the recommended changes. Changes are not applied to the system. 

.EXAMPLE
    .\CtxOptimizerEngine.ps1 -Source C:\Temp\Win10.xml -Mode Execute
    Process all entries from Win10.xml file. These changes are applied to the operating system. 

.EXAMPLE
    .\CtxOptimizerEngine.ps1 -Source C:\Temp\Win10.xml -Mode Execute -Groups "DisableServices", "RemoveApplications"
    Process entries from groups "Disable Services" and "Remove built-in applications" in Win10.xml file. These changes are applied to the operating system. 

.EXAMPLE
    .\CtxOptimizerEngine.ps1 -Source C:\Temp\Win10.xml -Mode Execute -OutputXml C:\Temp\Rollback.xml
    Process all entries from Win10.xml file. These changes are applied to the operating system. Save the rollback instructions in the file rollback.xml. 

.EXAMPLE
    .\CtxOptimizerEngine.ps1 -Source C:\Temp\Rollback.xml -Mode Rollback
    Revert all changes from the file rollback.xml.

.NOTES
    Author: Martin Zugec
    Date:   February 17, 2017

.LINK
    https://support.citrix.com/article/CTX224676    
#>

#Requires -Version 2

Param (
    [Parameter(Mandatory=$true)]
    [Alias("Template")]

    [System.String]$Source,

    [ValidateSet('analyze','execute','rollback')]

    [System.String]$Mode = "Analyze",

    [Array]$Groups,

    [String]$OutputHtml,

    [String]$OutputXml,

    [Switch]$OptimizerUI
)

Write-Host "------------------------------"
Write-Host "| Citrix Optimization Engine |"
Write-Host "| Version 1.0.50             |"
Write-Host "------------------------------"
Write-Host

Write-Host "Running in " -NoNewline 
Write-Host -ForegroundColor Yellow $Mode -NoNewLine 
Write-Host " mode"

# Error handling
$Global:ErrorActionPreference = "Stop"

# Create enumeration for PluginMode. Enumeration cannot be used in the param() section, as that would require a DynamicParam on a script level.
[String]$PluginMode = $Mode

# Just in case if previous run failed, make sure that all modules are reloaded
Remove-Module CTXOEP*

# Test if current host supports transcription or not. PowerShell ISE is one of the hosts that doesn't support transcription. 
Function Test-SupportsTranscription {
    $externalHost = $Host.GetType().GetProperty("ExternalHost",[Reflection.BindingFlags]"NonPublic,Instance").GetValue($host, @())

    Try {
        [Void]$externalHost.GetType().GetProperty("IsTranscribing",[Reflection.BindingFlags]"NonPublic,Instance").GetValue($externalHost, @())
        Return $True
    } Catch {
        Return $False
    }
}

# Test if current host is transcribing or not. 
Function Test-IsTranscribing {
    $externalHost = $Host.GetType().GetProperty("ExternalHost",[Reflection.BindingFlags]"NonPublic,Instance").GetValue($host, @())

    Try {
        Return $externalHost.GetType().GetProperty("IsTranscribing",[Reflection.BindingFlags]"NonPublic,Instance").GetValue($externalHost, @())
    } Catch {
        Return $False
    }
}

# Create $CTXOE_Main variable that defines folder where the script is located. If code is executed manually (copy & paste to Powershell window), current directory is being used
If ($MyInvocation.MyCommand.Path -is [Object]) {
    [string]$Global:CTXOE_Main = $(Split-Path -Parent $MyInvocation.MyCommand.Path)
} Else {
    [string]$Global:CTXOE_Main = $(Get-Location).Path
}

# Create Logs folder if it doesn't exists
$Global:CTXOE_LogFolder = "$CTXOE_Main\Logs\$([DateTime]::Now.ToString('yyyy-MM-dd_HH-mm-ss'))"

If ($(Test-Path "$CTXOE_LogFolder") -eq $false) {
    Write-Host "Creating Logs folder $(Split-Path -Leaf $CTXOE_LogFolder)"
    MkDir $CTXOE_LogFolder | Out-Null
}

# Report the location of log folder to UI
If ($OptimizerUI) {
    $LogFolder = New-Object -TypeName PSObject
    $LogFolder.PSObject.TypeNames.Insert(0,"logfolder")
    $LogFolder | Add-Member -MemberType NoteProperty -Name Location -Value $CTXOE_LogFolder
    Write-Output $LogFolder
}

# Initialize debug log (transcript). PowerShell ISE doesn't support transcriptions at the moment. 
Write-Host "Starting session log"

If (Test-SupportsTranscription) {
    If (Test-IsTranscribing) {Stop-Transcript}
    $CTXOE_DebugLog = "$CTXOE_LogFolder\Log_Debug_CTXOE.log"
    Start-Transcript -Append -Path "$CTXOE_DebugLog"
}

# Check if user is administrator
Write-Host "Checking permissions"
If (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Throw "You must be administrator in order to execute this script"
}

# Check if -Source is a fullpath or just name of the template. If it's just the name, expand to a fullpath. 
If (-not $Source.Contains("\")) {
    If (-not $Source.ToLower().EndsWith(".xml")) {
         $Source = "$Source.xml";
    }

    $Source = "$CTXOE_Main\Templates\$Source"; 
}

# Specify the default location of output XML
[String]$ResultsXml = "$CTXOE_LogFolder\$($PluginMode)_History.xml"
If ($OutputHtml.Length -eq 0) {
    [String]$OutputHtml = "$CTXOE_LogFolder\$($PluginMode)_History.html"
}

# Add CTXOE modules to PSModulePath variable. With this modules can be loaded dynamically based on the prefix. 
Write-Host "Adding CTXOE modules"
$Global:CTXOE_Modules = "$CTXOE_Main\Modules"
$Env:PSModulePath = "$([Environment]::GetEnvironmentVariable("PSModulePath"));$($Global:CTXOE_Modules)"

# Older version of PowerShell cannot load modules on-demand. All modules are pre-loaded. 
If ($Host.Version.Major -eq 2) {
    Write-Host "Detected older version of PowerShell. Importing all modules manually."
    ForEach ($m_Module in $(Get-ChildItem -Path "$CTXOE_Main\Modules" -Recurse -Filter "*.psm1")) {
        Import-Module -Name $m_Module.FullName
    }
}

Write-Host
Write-Host "Processing definition file $Source"
[Xml]$PackDefinitionXml = Get-Content $Source

# If mode is rollback, check if definition file contains the required history elements
If ($PluginMode -eq "Rollback") {
    If ($PackDefinitionXml.SelectNodes("//rollbackparams").Count -eq 0) {
        Throw "You need to select a log file from execution for rollback. This is usually called execute_history.xml. The file specified doesn't include instructions for rollback" 
    }
}

ForEach ($m_Pack in $PackDefinitionXml.SelectNodes("/root/pack")) {
    Write-Host "    Pack: " -NoNewline
    Write-Host $($m_Pack.Name) -ForegroundColor Yellow
    Write-Host "    Vendor: $($m_Pack.Vendor)"
    Write-Host "    Version: $($m_Pack.Version)"
    Write-Host "    Description: $($m_Pack.Description)"

    If ($m_Pack.Enabled -eq "0") {
        Write-Host "    This pack is disabled, skipping" -ForegroundColor DarkGray
        Continue
    }

    ForEach ($m_Group in $m_Pack.SelectNodes("./group")) {
        Write-Host
        Write-Host "        Group: $($m_Group.DisplayName)"
        Write-Host "        Group ID: $($m_Group.ID)"

        If ($Groups.Count -gt 0 -and $Groups -notcontains $m_Group.ID) {
            Write-Host "        Group not included in the -Groups argument, skipping"
            Continue
        }

        If ($m_Group.Enabled -eq "0") {
            Write-Host "    This group is disabled, skipping" -ForegroundColor DarkGray
            Continue
        }

        ForEach ($m_Entry in $m_Group.SelectNodes("./entry")) {
            Write-Host "            $($m_Entry.Name) - " -NoNewline

            If ($m_Entry.Enabled -eq "0") {
                Write-Host "    This entry is disabled, skipping" -ForegroundColor DarkGray
                CTXOE\New-CTXOEHistoryElement -Element $m_Entry -SystemChanged $False -StartTime $([DateTime]::Now) -Result $False -Details "Entry is disabled"

                Continue
            }

            If ($m_Entry.Execute -eq "0") {
                Write-Host " Entry is not marked for execution, skipping" -ForegroundColor DarkGray
                CTXOE\New-CTXOEHistoryElement -Element $m_Entry -SystemChanged $False -StartTime $([DateTime]::Now) -Result $False -Details "Entry is not marked for execution, skipping"

                Continue
            }

            $m_Action = $m_Entry.SelectSingleNode("./action")
            Write-Verbose "            Plugin: $($m_Action.Plugin)"

            # While some plugins can use only a single set of instructions to perform all the different operations (typically services or registry keys), this might not be always possible. 

            # Good example is "PowerShell" plugin - different code can be used to analyze the action and execute the action (compare "Get-CurrentState -eq $True" for analyze to "Set-CurrentState -Mode Example -Setup Mode1" for execute mode).

            # In order to support this scenarios, it is possible to override the default <params /> element with a custom element for analyze and rollback phases. Default is still <params />. With this implementation, there can be an action that will implement all three elements (analyzeparams, rollbackparams and executeparams). 

            [String]$m_ParamsElementName = "params"
            [String]$m_OverrideElement = "$($PluginMode.ToLower())$m_ParamsElementName"

            If ($m_Action.$m_OverrideElement -is [Object]) {
                Write-Verbose "Using custom <$($m_OverrideElement) /> element"
                $m_ParamsElementName = $m_OverrideElement
            }

            # To prevent any unexpected damage to the system, Rollback mode requires use of custom params object and cannot use the default one. 
            If ($PluginMode -eq "Rollback" -and $m_Action.$m_OverrideElement -isnot [Object]) {
                If ($m_Entry.history.systemchanged -eq "0") {
                    Write-Host "This entry has not changed, skip" -ForegroundColor DarkGray
                    Continue
                } Else {
                    Write-Host "Rollback mode requires custom instructions that are not available, skip" -ForegroundColor DarkGray
                    Continue
                }
            }

            # Reset variables that are used to report the status
            $Global:CTXOE_Result = $False
            $Global:CTXOE_Details = "No data reported by plugin"

            # Two variables used by rollback. First identify that this entry has modified the system. The second should contain information required for rollback of those changes (if possible). This is required only for "execute" mode. 
            [Boolean]$Global:CTXOE_SystemChanged = $False

            $Global:CTXOE_ChangeRollbackParams = $Null

            [DateTime]$StartTime = Get-Date; 
            CTXOE\Invoke-CTXOEPlugin -PluginName $($m_Action.Plugin) -Params $m_Action.$m_ParamsElementName -Mode $PluginMode -Verbose

            If ($CTXOE_Result -eq $false) {
                Write-Host -ForegroundColor Red $CTXOE_Details
            } Else {
                Write-Host -ForegroundColor Green $CTXOE_Details
            }

            # Save information about changes as an element
            CTXOE\New-CTXOEHistoryElement -Element $m_Entry -SystemChanged $CTXOE_SystemChanged -StartTime $StartTime -Result $CTXOE_Result -Details $CTXOE_Details -RollbackInstructions $CTXOE_ChangeRollbackParams

            If ($OptimizerUI) {
                $history = New-Object -TypeName PSObject
                $history.PSObject.TypeNames.Insert(0,"history")
                $history | Add-Member -MemberType NoteProperty -Name GroupID -Value $m_Group.ID
                $history | Add-Member -MemberType NoteProperty -Name EntryName -Value $m_Entry.Name
                $history | Add-Member -MemberType NoteProperty -Name SystemChanged -Value $m_Entry.SystemChanged
                $history | Add-Member -MemberType NoteProperty -Name StartTime -Value $m_Entry.History.StartTime
                $history | Add-Member -MemberType NoteProperty -Name EndTime -Value $m_Entry.History.EndTime
                $history | Add-Member -MemberType NoteProperty -Name Result -Value $m_Entry.History.Return.Result
                $history | Add-Member -MemberType NoteProperty -Name Details -Value $m_Entry.History.Return.Details

                Write-Output $history
                #Write-Output $m_Entry
            }
        }
    }
}

# Save the output in XML format for further parsing\history
$PackDefinitionXml.Save($ResultsXml);

# Use transformation file to generate HTML report
$XSLT = New-Object System.Xml.Xsl.XslCompiledTransform;
$XSLT.Load("$CTXOE_Main\CtxOptimizerReport.xslt");
$XSLT.Transform($ResultsXml, $OutputHtml);

# If another location is requested, save the XML file here as well. 
If ($OutputXml.Length -gt 0) {
    $PackDefinitionXml.Save($OutputXml); 
}

# If the current host is trascribing, save the transcription
If (Test-IsTranscribing) {Stop-Transcript}
# SIG # Begin signature block
# MIIYIAYJKoZIhvcNAQcCoIIYETCCGA0CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU/3l+N4sk5aqIxiMyDnv7EQYo
# JDagghL5MIID7jCCA1egAwIBAgIQfpPr+3zGTlnqS5p31Ab8OzANBgkqhkiG9w0B
# AQUFADCBizELMAkGA1UEBhMCWkExFTATBgNVBAgTDFdlc3Rlcm4gQ2FwZTEUMBIG
# A1UEBxMLRHVyYmFudmlsbGUxDzANBgNVBAoTBlRoYXd0ZTEdMBsGA1UECxMUVGhh
# d3RlIENlcnRpZmljYXRpb24xHzAdBgNVBAMTFlRoYXd0ZSBUaW1lc3RhbXBpbmcg
# Q0EwHhcNMTIxMjIxMDAwMDAwWhcNMjAxMjMwMjM1OTU5WjBeMQswCQYDVQQGEwJV
# UzEdMBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xMDAuBgNVBAMTJ1N5bWFu
# dGVjIFRpbWUgU3RhbXBpbmcgU2VydmljZXMgQ0EgLSBHMjCCASIwDQYJKoZIhvcN
# AQEBBQADggEPADCCAQoCggEBALGss0lUS5ccEgrYJXmRIlcqb9y4JsRDc2vCvy5Q
# WvsUwnaOQwElQ7Sh4kX06Ld7w3TMIte0lAAC903tv7S3RCRrzV9FO9FEzkMScxeC
# i2m0K8uZHqxyGyZNcR+xMd37UWECU6aq9UksBXhFpS+JzueZ5/6M4lc/PcaS3Er4
# ezPkeQr78HWIQZz/xQNRmarXbJ+TaYdlKYOFwmAUxMjJOxTawIHwHw103pIiq8r3
# +3R8J+b3Sht/p8OeLa6K6qbmqicWfWH3mHERvOJQoUvlXfrlDqcsn6plINPYlujI
# fKVOSET/GeJEB5IL12iEgF1qeGRFzWBGflTBE3zFefHJwXECAwEAAaOB+jCB9zAd
# BgNVHQ4EFgQUX5r1blzMzHSa1N197z/b7EyALt0wMgYIKwYBBQUHAQEEJjAkMCIG
# CCsGAQUFBzABhhZodHRwOi8vb2NzcC50aGF3dGUuY29tMBIGA1UdEwEB/wQIMAYB
# Af8CAQAwPwYDVR0fBDgwNjA0oDKgMIYuaHR0cDovL2NybC50aGF3dGUuY29tL1Ro
# YXd0ZVRpbWVzdGFtcGluZ0NBLmNybDATBgNVHSUEDDAKBggrBgEFBQcDCDAOBgNV
# HQ8BAf8EBAMCAQYwKAYDVR0RBCEwH6QdMBsxGTAXBgNVBAMTEFRpbWVTdGFtcC0y
# MDQ4LTEwDQYJKoZIhvcNAQEFBQADgYEAAwmbj3nvf1kwqu9otfrjCR27T4IGXTdf
# plKfFo3qHJIJRG71betYfDDo+WmNI3MLEm9Hqa45EfgqsZuwGsOO61mWAK3ODE2y
# 0DGmCFwqevzieh1XTKhlGOl5QGIllm7HxzdqgyEIjkHq3dlXPx13SYcqFgZepjhq
# IhKjURmDfrYwggSjMIIDi6ADAgECAhAOz/Q4yP6/NW4E2GqYGxpQMA0GCSqGSIb3
# DQEBBQUAMF4xCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRTeW1hbnRlYyBDb3Jwb3Jh
# dGlvbjEwMC4GA1UEAxMnU3ltYW50ZWMgVGltZSBTdGFtcGluZyBTZXJ2aWNlcyBD
# QSAtIEcyMB4XDTEyMTAxODAwMDAwMFoXDTIwMTIyOTIzNTk1OVowYjELMAkGA1UE
# BhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMTQwMgYDVQQDEytT
# eW1hbnRlYyBUaW1lIFN0YW1waW5nIFNlcnZpY2VzIFNpZ25lciAtIEc0MIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAomMLOUS4uyOnREm7Dv+h8GEKU5Ow
# mNutLA9KxW7/hjxTVQ8VzgQ/K/2plpbZvmF5C1vJTIZ25eBDSyKV7sIrQ8Gf2Gi0
# jkBP7oU4uRHFI/JkWPAVMm9OV6GuiKQC1yoezUvh3WPVF4kyW7BemVqonShQDhfu
# ltthO0VRHc8SVguSR/yrrvZmPUescHLnkudfzRC5xINklBm9JYDh6NIipdC6Anqh
# d5NbZcPuF3S8QYYq3AhMjJKMkS2ed0QfaNaodHfbDlsyi1aLM73ZY8hJnTrFxeoz
# C9Lxoxv0i77Zs1eLO94Ep3oisiSuLsdwxb5OgyYI+wu9qU+ZCOEQKHKqzQIDAQAB
# o4IBVzCCAVMwDAYDVR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDAO
# BgNVHQ8BAf8EBAMCB4AwcwYIKwYBBQUHAQEEZzBlMCoGCCsGAQUFBzABhh5odHRw
# Oi8vdHMtb2NzcC53cy5zeW1hbnRlYy5jb20wNwYIKwYBBQUHMAKGK2h0dHA6Ly90
# cy1haWEud3Muc3ltYW50ZWMuY29tL3Rzcy1jYS1nMi5jZXIwPAYDVR0fBDUwMzAx
# oC+gLYYraHR0cDovL3RzLWNybC53cy5zeW1hbnRlYy5jb20vdHNzLWNhLWcyLmNy
# bDAoBgNVHREEITAfpB0wGzEZMBcGA1UEAxMQVGltZVN0YW1wLTIwNDgtMjAdBgNV
# HQ4EFgQURsZpow5KFB7VTNpSYxc/Xja8DeYwHwYDVR0jBBgwFoAUX5r1blzMzHSa
# 1N197z/b7EyALt0wDQYJKoZIhvcNAQEFBQADggEBAHg7tJEqAEzwj2IwN3ijhCcH
# bxiy3iXcoNSUA6qGTiWfmkADHN3O43nLIWgG2rYytG2/9CwmYzPkSWRtDebDZw73
# BaQ1bHyJFsbpst+y6d0gxnEPzZV03LZc3r03H0N45ni1zSgEIKOq8UvEiCmRDoDR
# EfzdXHZuT14ORUZBbg2w6jiasTraCXEQ/Bx5tIB7rGn0/Zy2DBYr8X9bCT2bW+IW
# yhOBbQAuOA2oKY8s4bL0WqkBrxWcLC9JG9siu8P+eJRRw4axgohd8D20UaF5Mysu
# e7ncIAkTcetqGVvP6KUwVyyJST+5z3/Jvz4iaGNTmr1pdKzFHTx/kuDDvBzYBHUw
# ggT/MIID56ADAgECAhBQr8o3SwnhP4oF6kzkfrEFMA0GCSqGSIb3DQEBCwUAMH8x
# CzAJBgNVBAYTAlVTMR0wGwYDVQQKExRTeW1hbnRlYyBDb3Jwb3JhdGlvbjEfMB0G
# A1UECxMWU3ltYW50ZWMgVHJ1c3QgTmV0d29yazEwMC4GA1UEAxMnU3ltYW50ZWMg
# Q2xhc3MgMyBTSEEyNTYgQ29kZSBTaWduaW5nIENBMB4XDTE3MDEzMTAwMDAwMFoX
# DTE4MDEzMTIzNTk1OVowgZYxCzAJBgNVBAYTAlVTMRAwDgYDVQQIDAdGbG9yaWRh
# MRgwFgYDVQQHDA9Gb3J0IExhdWRlcmRhbGUxHTAbBgNVBAoMFENpdHJpeCBTeXN0
# ZW1zLCBJbmMuMR0wGwYDVQQLDBRYZW5BcHAoU2VydmVyU0hBMjU2KTEdMBsGA1UE
# AwwUQ2l0cml4IFN5c3RlbXMsIEluYy4wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
# ggEKAoIBAQDtkgVPpUMSAQNv0qsiKSRSC4gZgbZS6sbGxwH9IWFTZ37YbkVju16a
# elVVvCjfwjvsVjWXDiSaqKHiZyiBnbPZhsvmEMfYit5EfzxEBt+rpmJMLCbkTfOr
# GmuMSVl6VFgu8fcr/ZSBTeCf64OBt8QGJJpDt1L3zCGdgGg82sViDkzLCpxafei7
# GdXpUVTmk8XXhkps2hRvk5sGEdUu5fhbp8mZJVJj9k8JrEkzEB7nvUHF8ZjvyFcl
# NFErFzGmRzVrSvNRbs/ajaFlWhqGmKs/JJL2QvKHWifEI+4zA1YlfeRTi0h2s8S+
# k76e4dyYmIJIyPozzwSRYjO6f79aQXNdAgMBAAGjggFdMIIBWTAJBgNVHRMEAjAA
# MA4GA1UdDwEB/wQEAwIHgDArBgNVHR8EJDAiMCCgHqAchhpodHRwOi8vc3Yuc3lt
# Y2IuY29tL3N2LmNybDBhBgNVHSAEWjBYMFYGBmeBDAEEATBMMCMGCCsGAQUFBwIB
# FhdodHRwczovL2Quc3ltY2IuY29tL2NwczAlBggrBgEFBQcCAjAZDBdodHRwczov
# L2Quc3ltY2IuY29tL3JwYTATBgNVHSUEDDAKBggrBgEFBQcDAzBXBggrBgEFBQcB
# AQRLMEkwHwYIKwYBBQUHMAGGE2h0dHA6Ly9zdi5zeW1jZC5jb20wJgYIKwYBBQUH
# MAKGGmh0dHA6Ly9zdi5zeW1jYi5jb20vc3YuY3J0MB8GA1UdIwQYMBaAFJY7U/B5
# M5evfYPvLivMyreGHnJmMB0GA1UdDgQWBBRhAiqDE5/hHbTckV8t1K3VNfQsNDAN
# BgkqhkiG9w0BAQsFAAOCAQEAlemHsB2pgUA26inUeizf9LYRVw8XUKW5uHapau4A
# CM0g6IQsWgdcU4Quydh6y2/Z6B+kZZ/Rk4Pfk3/LXD+Fixi8gHoTxNYO+NbPoCEl
# wI4hxmW43LeGj7+b+QPYzE2xh/83zUtPcHdHVzk0qTeeehVPdvsXO8ujW7xqGXgR
# egNGkavY2BgXBB/KAVkVGBwApOQqDE2scgGfUP9IW8mcSPiH0z3KGHItycUDQocl
# lwLX38m00jHQChr/IFRUisJRQtfNAZ+kJEetbkTbsHE2b+CUDLEC34+b6fUpImuz
# 0SawiPfu3QXNoicsz5SxcIrgHNhX+JnFw8tfnMJMVIbmEzCCBVkwggRBoAMCAQIC
# ED141/l2SWCyYX308B7KhiowDQYJKoZIhvcNAQELBQAwgcoxCzAJBgNVBAYTAlVT
# MRcwFQYDVQQKEw5WZXJpU2lnbiwgSW5jLjEfMB0GA1UECxMWVmVyaVNpZ24gVHJ1
# c3QgTmV0d29yazE6MDgGA1UECxMxKGMpIDIwMDYgVmVyaVNpZ24sIEluYy4gLSBG
# b3IgYXV0aG9yaXplZCB1c2Ugb25seTFFMEMGA1UEAxM8VmVyaVNpZ24gQ2xhc3Mg
# MyBQdWJsaWMgUHJpbWFyeSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eSAtIEc1MB4X
# DTEzMTIxMDAwMDAwMFoXDTIzMTIwOTIzNTk1OVowfzELMAkGA1UEBhMCVVMxHTAb
# BgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8wHQYDVQQLExZTeW1hbnRlYyBU
# cnVzdCBOZXR3b3JrMTAwLgYDVQQDEydTeW1hbnRlYyBDbGFzcyAzIFNIQTI1NiBD
# b2RlIFNpZ25pbmcgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCX
# gx4AFq8ssdIIxNdok1FgHnH24ke021hNI2JqtL9aG1H3ow0Yd2i72DarLyFQ2p7z
# 518nTgvCl8gJcJOp2lwNTqQNkaC07BTOkXJULs6j20TpUhs/QTzKSuSqwOg5q1PM
# IdDMz3+b5sLMWGqCFe49Ns8cxZcHJI7xe74xLT1u3LWZQp9LYZVfHHDuF33bi+Vh
# iXjHaBuvEXgamK7EVUdT2bMy1qEORkDFl5KK0VOnmVuFNVfT6pNiYSAKxzB3JBFN
# YoO2untogjHuZcrf+dWNsjXcjCtvanJcYISc8gyUXsBWUgBIzNP4pX3eL9cT5Dio
# hNVGuBOGwhud6lo43ZvbAgMBAAGjggGDMIIBfzAvBggrBgEFBQcBAQQjMCEwHwYI
# KwYBBQUHMAGGE2h0dHA6Ly9zMi5zeW1jYi5jb20wEgYDVR0TAQH/BAgwBgEB/wIB
# ADBsBgNVHSAEZTBjMGEGC2CGSAGG+EUBBxcDMFIwJgYIKwYBBQUHAgEWGmh0dHA6
# Ly93d3cuc3ltYXV0aC5jb20vY3BzMCgGCCsGAQUFBwICMBwaGmh0dHA6Ly93d3cu
# c3ltYXV0aC5jb20vcnBhMDAGA1UdHwQpMCcwJaAjoCGGH2h0dHA6Ly9zMS5zeW1j
# Yi5jb20vcGNhMy1nNS5jcmwwHQYDVR0lBBYwFAYIKwYBBQUHAwIGCCsGAQUFBwMD
# MA4GA1UdDwEB/wQEAwIBBjApBgNVHREEIjAgpB4wHDEaMBgGA1UEAxMRU3ltYW50
# ZWNQS0ktMS01NjcwHQYDVR0OBBYEFJY7U/B5M5evfYPvLivMyreGHnJmMB8GA1Ud
# IwQYMBaAFH/TZafC3ey78DAJ80M5+gKvMzEzMA0GCSqGSIb3DQEBCwUAA4IBAQAT
# hRoeaak396C9pK9+HWFT/p2MXgymdR54FyPd/ewaA1U5+3GVx2Vap44w0kRaYdtw
# b9ohBcIuc7pJ8dGT/l3JzV4D4ImeP3Qe1/c4i6nWz7s1LzNYqJJW0chNO4LmeYQW
# /CiwsUfzHaI+7ofZpn+kVqU/rYQuKd58vKiqoz0EAeq6k6IOUCIpF0yH5DoRX9ak
# JYmbBWsvtMkBTCd7C6wZBSKgYBU/2sn7TUyP+3Jnd/0nlMe6NQ6ISf6N/SivShK9
# DbOXBd5EDBX6NisD3MFQAfGhEV0U5eK9J0tUviuEXg+mw3QFCu+Xw4kisR93873N
# Q9TxTKk/tYuEr2Ty0BQhMYIEkTCCBI0CAQEwgZMwfzELMAkGA1UEBhMCVVMxHTAb
# BgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8wHQYDVQQLExZTeW1hbnRlYyBU
# cnVzdCBOZXR3b3JrMTAwLgYDVQQDEydTeW1hbnRlYyBDbGFzcyAzIFNIQTI1NiBD
# b2RlIFNpZ25pbmcgQ0ECEFCvyjdLCeE/igXqTOR+sQUwCQYFKw4DAhoFAKCBxDAZ
# BgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYB
# BAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUHn5gk66jWlyOJnSHbQ6yn82LdygwZAYK
# KwYBBAGCNwIBDDFWMFSgOIA2AEMAaQB0AHIAaQB4ACAAUwB1AHAAcABvAHIAdABh
# AGIAaQBsAGkAdAB5ACAAVABvAG8AbABzoRiAFmh0dHA6Ly93d3cuY2l0cml4LmNv
# bSAwDQYJKoZIhvcNAQEBBQAEggEAAZsTRty62tPyH9SR0T5dtsCw+tdWBvqJASK3
# HEIwRAN/P6b0uXVFhjhcfcB3QJDEPGBqgVLL06nNatUsTtzeYVl0N/huwTbNKjs0
# e8bIIaeYwCqQ8yigG5MoTXWMO0ob/bxNLXDD0dsEmRoIVWeEGG2SMai0iHsth0IU
# sXgAiamyQ9mxm54h+wr1yYRH5hVL/Eb2ylz7YVVa2xrkjkcCW4RGtBWqcutXnDkt
# t2elxw/kSyQWYUBvaGn/DcqzRnwzY8rwiKRgj8rqvTrpnYOXTSaITze0NxyP1Avd
# sVRb6i6GUXg8YmDa/DayaqMd8ei3VQzTDzUTGiM098lZI/WMzqGCAgswggIHBgkq
# hkiG9w0BCQYxggH4MIIB9AIBATByMF4xCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRT
# eW1hbnRlYyBDb3Jwb3JhdGlvbjEwMC4GA1UEAxMnU3ltYW50ZWMgVGltZSBTdGFt
# cGluZyBTZXJ2aWNlcyBDQSAtIEcyAhAOz/Q4yP6/NW4E2GqYGxpQMAkGBSsOAwIa
# BQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0x
# NzExMzAxOTU4MzhaMCMGCSqGSIb3DQEJBDEWBBSf3GHFzK7VwPfwDqe5VfmOyy1s
# RDANBgkqhkiG9w0BAQEFAASCAQA9BEi81lGVlrKaa7kOhH0GvKk2qB8W6jjj5tcW
# UGCiyanPVUJFP5hWh3mUfgi2bBbdZbupNqWFlasyfJ9R+DU1GNFbw6FdJ2pXW1Vc
# vApHx5GOHnWi6NCoMn7KftZ4Zg8+aPn3FEqszNrtFVPLo5m5oXPFnQcPtmGyBRJr
# mb7/lcBlGnC/OISaie0RE/y5UEm7WuEc0Gj1fE8x1eBYJ3hphI7CBJt+Jy0LYXky
# HOky99rOG9d5rvW7h2CC3/7LEupGKQs51GS2tlPizhVVHBBQWw43+ZzSMheJ6dS3
# lhI64gFeIgxxXLlFo9duIC/XPHQFUNE0aywu0Ayy5r12S2PJ
# SIG # End signature block
