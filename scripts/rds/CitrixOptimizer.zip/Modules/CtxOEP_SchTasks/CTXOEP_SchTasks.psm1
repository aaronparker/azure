﻿# In order to support both Windows 7 and Windows 10, Get-ScheduledTask cannot be used. Original code was using schtasks, but since it's language specific, it had to be replaced with COM object Schedule.Service. 
$CTXOESchTasks_COMSchedule = New-Object –ComObject ("Schedule.Service")
$CTXOESchTasks_COMSchedule.Connect("localhost")

# Function to return all subfolders for scheduled tasks
Function Get-CTXOESchTasksSubfolders ($Folder) {
    [Array]$m_Subfolders = @()
    
    If ($Folder.Path -eq "\") {$m_Subfolders += $Folder}
    
    ForEach ($m_Folder in  $Folder.GetFolders(1)) {
        $m_Subfolders += $m_Folder;
        ForEach ($m_Subfolder in $(Get-CTXOESchTasksSubfolders -Folder $m_Folder)) {
            $m_Subfolders += $m_Subfolder;
        }
    }
    Return $m_Subfolders;
}

# function to return all scheduled tasks
Function Get-CTXOESchTasksTasks () {
    [Array]$m_Tasks = @()
    ForEach ($m_Subfolder in Get-CTXOESchTasksSubfolders -Folder $CTXOESchTasks_COMSchedule.GetFolder("\")) {
        $m_Tasks += $m_Subfolder.GetTasks(1);
    }
    Return $m_Tasks;
}

# Generate cache of all scheduled tasks
$CTXOESchTasks_Cache = Get-CTXOESchTasksTasks;
$CTXOESchTasks_IsCacheValid = $true;

# Check if leading and trailing "\" are available, if not append and return modified string
Function Test-CTXOESchTasksBackslashes ([string]$Path) {
    If ($Path -notlike "\*") {$Path = "\$Path"}

    If ($Path -notlike "*\") {$Path = "$Path\"}

    Return $Path
}

# Check if scheduled task exists
Function Test-CTXOESchTasksExist ([String]$Path) {
    Return $($CTXOESchTasks_Cache | Where {$_.Path -eq "$Path"}) -is [Object]
}

# Check if scheduled task is enabled or disabled. Return $False for disabled, $True for enabled.
Function Test-CTXOESchTasksState ([String]$Path) {
    If ($CTXOESchTasks_IsCacheValid -eq $false) {$CTXOESchTasks_Cache = Get-CTXOESchTasksTasks};    
    Return [Boolean]$($CTXOESchTasks_Cache | Where {$_.Path -eq $Path} | Select -ExpandProperty Enabled)
}

Function Invoke-CTXOESchTasksExecuteInternal ([Xml.XmlElement]$Params, [Boolean]$RollbackSupported = $False) {


    [String]$m_Name = $Params.Name
    [String]$m_Path = Test-CTXOESchTasksBackslashes -Path $Params.Path
    [String]$m_State = $Params.Value
    [String]$m_FullPath = "$m_Path$m_Name"

    If ($m_State -ne "Disabled" -and $m_State -ne "Enabled") {Throw "Requested state is $m_State, which is not disabled or enabled"}

    [Boolean]$m_Exists = Test-CTXOESchTasksExist -Path $m_FullPath

    # If scheduled task does not exist, return $True if goal was to disable it, otherwise return $False
    If ($m_Exists -eq $False) {
        $Global:CTXOE_Result = $m_State -eq "Disabled"
        $Global:CTXOE_Details = "Scheduled task does not exist"
        Return
    }

    [Boolean]$m_CurrentState = Test-CTXOESchTasksState -Path $m_FullPath
    [Boolean]$m_DesiredState = $m_State -ne "Disabled"

    If ($m_DesiredState -eq $m_CurrentState) {
        $Global:CTXOE_Result = $True
        $Global:CTXOE_Details = "Scheduled Task already $($m_State)"
        Return
    } Else {

        $CTXOESchTasks_IsCacheValid = $false;
        [String]$m_RollbackState = ""

        If ($m_State -eq "Disabled") {
            schtasks /change /tn "$m_FullPath" /disable | Out-Null
            $CTXOESchTasks_IsCacheValid = $False;
            $m_RollbackState = "Enabled";
        } Else {
            schtasks /change /tn "$m_FullPath" /enable | Out-Null
            $CTXOESchTasks_IsCacheValid = $False;
            $m_RollbackState = "Disabled"
        }

        [Boolean]$m_CurrentState = Test-CTXOESchTasksState -Path $m_FullPath
    
        If ($m_DesiredState -eq $m_CurrentState) {
            $Global:CTXOE_Result = $True
            $Global:CTXOE_Details = "Scheduled Task has been $($m_State)"

            # System has been changed. Report it and generate a rollback element.
            $Global:CTXOE_SystemChanged = $true;
            If ($RollbackSupported) {
                [Xml.XmlDocument]$m_RollbackElement = CTXOE\ConvertTo-CTXOERollbackElement -Element $Params
                $m_RollbackElement.rollbackparams.value = $m_RollbackState
                $Global:CTXOE_ChangeRollbackParams = $m_RollbackElement
            }

            Return
        } Else {
            $Global:CTXOE_Result = $False
            $Global:CTXOE_Details = "Failed to set $($m_Name) to $($m_State) state"
            Return
        }
    }
    Return
}

Function Invoke-CTXOESchTasksAnalyze ([Xml.XmlElement]$Params) {

    [String]$m_Name = $Params.Name
    [String]$m_Path = Test-CTXOESchTasksBackslashes -Path $Params.Path
    [String]$m_State = $Params.Value
    [String]$m_FullPath = "$m_Path$m_Name"

    # If scheduled task does not exist, return $True if goal was to disable it, otherwise return $False
    If ($(Test-CTXOESchTasksExist -Path $m_FullPath) -eq $False) {
        $Global:CTXOE_Result = $m_State -eq "Disabled"
        $Global:CTXOE_Details = "Scheduled task does not exist"
        Return
    }

    [Boolean]$m_CurrentState = Test-CTXOESchTasksState -Path $m_FullPath

    If ($m_State -eq "Disabled" -and $m_CurrentState -eq $False) {
        $Global:CTXOE_Result = $True
        $Global:CTXOE_Details = "Scheduled Task is disabled"
    } ElseIf ($m_State -ne "Disabled" -and $m_CurrentState -ne $False) {
        $Global:CTXOE_Result = $True
        $Global:CTXOE_Details = "Scheduled Task is enabled"
    } Else {
        $Global:CTXOE_Result = $False
        $Global:CTXOE_Details = "Scheduled Task is not in $($m_State) state"
    }

    Return
}

Function Invoke-CTXOESchTasksExecute ([Xml.XmlElement]$Params) {
    Invoke-CTXOESchTasksExecuteInternal -Params $Params -RollbackSupported $true
}

Function Invoke-CTXOESchTasksRollback ([Xml.XmlElement]$Params) {
    Invoke-CTXOESchTasksExecuteInternal -Params $Params -RollbackSupported $false
}
# SIG # Begin signature block
# MIIYIAYJKoZIhvcNAQcCoIIYETCCGA0CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUbr4k2gf7DH04aXoaVz1r8m07
# X9WgghL5MIID7jCCA1egAwIBAgIQfpPr+3zGTlnqS5p31Ab8OzANBgkqhkiG9w0B
# AQUFADCBizELMAkGA1UEBhMCWkExFTATBgNVBAgTDFdlc3Rlcm4gQ2FwZTEUMBIG
# A1UEBxMLRHVyYmFudmlsbGUxDzANBgNVBAoTBlRoYXd0ZTEdMBsGA1UECxMUVGhh
# d3RlIENlcnRpZmljYXRpb24xHzAdBgNVBAMTFlRoYXd0ZSBUaW1lc3RhbXBpbmcg
# Q0EwHhcNMTIxMjIxMDAwMDAwWhcNMjAxMjMwMjM1OTU5WjBeMQswCQYDVQQGEwJV
# UzEdMBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xMDAuBgNVBAMTJ1N5bWFu
# dGVjIFRpbWUgU3RhbXBpbmcgU2VydmljZXMgQ0EgLSBHMjCCASIwDQYJKoZIhvcN
# AQEBBQADggEPADCCAQoCggEBALGss0lUS5ccEgrYJXmRIlcqb9y4JsRDc2vCvy5Q
# WvsUwnaOQwElQ7Sh4kX06Ld7w3TMIte0lAAC903tv7S3RCRrzV9FO9FEzkMScxeC
# i2m0K8uZHqxyGyZNcR+xMd37UWECU6aq9UksBXhFpS+JzueZ5/6M4lc/PcaS3Er4
# ezPkeQr78HWIQZz/xQNRmarXbJ+TaYdlKYOFwmAUxMjJOxTawIHwHw103pIiq8r3
# +3R8J+b3Sht/p8OeLa6K6qbmqicWfWH3mHERvOJQoUvlXfrlDqcsn6plINPYlujI
# fKVOSET/GeJEB5IL12iEgF1qeGRFzWBGflTBE3zFefHJwXECAwEAAaOB+jCB9zAd
# BgNVHQ4EFgQUX5r1blzMzHSa1N197z/b7EyALt0wMgYIKwYBBQUHAQEEJjAkMCIG
# CCsGAQUFBzABhhZodHRwOi8vb2NzcC50aGF3dGUuY29tMBIGA1UdEwEB/wQIMAYB
# Af8CAQAwPwYDVR0fBDgwNjA0oDKgMIYuaHR0cDovL2NybC50aGF3dGUuY29tL1Ro
# YXd0ZVRpbWVzdGFtcGluZ0NBLmNybDATBgNVHSUEDDAKBggrBgEFBQcDCDAOBgNV
# HQ8BAf8EBAMCAQYwKAYDVR0RBCEwH6QdMBsxGTAXBgNVBAMTEFRpbWVTdGFtcC0y
# MDQ4LTEwDQYJKoZIhvcNAQEFBQADgYEAAwmbj3nvf1kwqu9otfrjCR27T4IGXTdf
# plKfFo3qHJIJRG71betYfDDo+WmNI3MLEm9Hqa45EfgqsZuwGsOO61mWAK3ODE2y
# 0DGmCFwqevzieh1XTKhlGOl5QGIllm7HxzdqgyEIjkHq3dlXPx13SYcqFgZepjhq
# IhKjURmDfrYwggSjMIIDi6ADAgECAhAOz/Q4yP6/NW4E2GqYGxpQMA0GCSqGSIb3
# DQEBBQUAMF4xCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRTeW1hbnRlYyBDb3Jwb3Jh
# dGlvbjEwMC4GA1UEAxMnU3ltYW50ZWMgVGltZSBTdGFtcGluZyBTZXJ2aWNlcyBD
# QSAtIEcyMB4XDTEyMTAxODAwMDAwMFoXDTIwMTIyOTIzNTk1OVowYjELMAkGA1UE
# BhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMTQwMgYDVQQDEytT
# eW1hbnRlYyBUaW1lIFN0YW1waW5nIFNlcnZpY2VzIFNpZ25lciAtIEc0MIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAomMLOUS4uyOnREm7Dv+h8GEKU5Ow
# mNutLA9KxW7/hjxTVQ8VzgQ/K/2plpbZvmF5C1vJTIZ25eBDSyKV7sIrQ8Gf2Gi0
# jkBP7oU4uRHFI/JkWPAVMm9OV6GuiKQC1yoezUvh3WPVF4kyW7BemVqonShQDhfu
# ltthO0VRHc8SVguSR/yrrvZmPUescHLnkudfzRC5xINklBm9JYDh6NIipdC6Anqh
# d5NbZcPuF3S8QYYq3AhMjJKMkS2ed0QfaNaodHfbDlsyi1aLM73ZY8hJnTrFxeoz
# C9Lxoxv0i77Zs1eLO94Ep3oisiSuLsdwxb5OgyYI+wu9qU+ZCOEQKHKqzQIDAQAB
# o4IBVzCCAVMwDAYDVR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDAO
# BgNVHQ8BAf8EBAMCB4AwcwYIKwYBBQUHAQEEZzBlMCoGCCsGAQUFBzABhh5odHRw
# Oi8vdHMtb2NzcC53cy5zeW1hbnRlYy5jb20wNwYIKwYBBQUHMAKGK2h0dHA6Ly90
# cy1haWEud3Muc3ltYW50ZWMuY29tL3Rzcy1jYS1nMi5jZXIwPAYDVR0fBDUwMzAx
# oC+gLYYraHR0cDovL3RzLWNybC53cy5zeW1hbnRlYy5jb20vdHNzLWNhLWcyLmNy
# bDAoBgNVHREEITAfpB0wGzEZMBcGA1UEAxMQVGltZVN0YW1wLTIwNDgtMjAdBgNV
# HQ4EFgQURsZpow5KFB7VTNpSYxc/Xja8DeYwHwYDVR0jBBgwFoAUX5r1blzMzHSa
# 1N197z/b7EyALt0wDQYJKoZIhvcNAQEFBQADggEBAHg7tJEqAEzwj2IwN3ijhCcH
# bxiy3iXcoNSUA6qGTiWfmkADHN3O43nLIWgG2rYytG2/9CwmYzPkSWRtDebDZw73
# BaQ1bHyJFsbpst+y6d0gxnEPzZV03LZc3r03H0N45ni1zSgEIKOq8UvEiCmRDoDR
# EfzdXHZuT14ORUZBbg2w6jiasTraCXEQ/Bx5tIB7rGn0/Zy2DBYr8X9bCT2bW+IW
# yhOBbQAuOA2oKY8s4bL0WqkBrxWcLC9JG9siu8P+eJRRw4axgohd8D20UaF5Mysu
# e7ncIAkTcetqGVvP6KUwVyyJST+5z3/Jvz4iaGNTmr1pdKzFHTx/kuDDvBzYBHUw
# ggT/MIID56ADAgECAhBQr8o3SwnhP4oF6kzkfrEFMA0GCSqGSIb3DQEBCwUAMH8x
# CzAJBgNVBAYTAlVTMR0wGwYDVQQKExRTeW1hbnRlYyBDb3Jwb3JhdGlvbjEfMB0G
# A1UECxMWU3ltYW50ZWMgVHJ1c3QgTmV0d29yazEwMC4GA1UEAxMnU3ltYW50ZWMg
# Q2xhc3MgMyBTSEEyNTYgQ29kZSBTaWduaW5nIENBMB4XDTE3MDEzMTAwMDAwMFoX
# DTE4MDEzMTIzNTk1OVowgZYxCzAJBgNVBAYTAlVTMRAwDgYDVQQIDAdGbG9yaWRh
# MRgwFgYDVQQHDA9Gb3J0IExhdWRlcmRhbGUxHTAbBgNVBAoMFENpdHJpeCBTeXN0
# ZW1zLCBJbmMuMR0wGwYDVQQLDBRYZW5BcHAoU2VydmVyU0hBMjU2KTEdMBsGA1UE
# AwwUQ2l0cml4IFN5c3RlbXMsIEluYy4wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
# ggEKAoIBAQDtkgVPpUMSAQNv0qsiKSRSC4gZgbZS6sbGxwH9IWFTZ37YbkVju16a
# elVVvCjfwjvsVjWXDiSaqKHiZyiBnbPZhsvmEMfYit5EfzxEBt+rpmJMLCbkTfOr
# GmuMSVl6VFgu8fcr/ZSBTeCf64OBt8QGJJpDt1L3zCGdgGg82sViDkzLCpxafei7
# GdXpUVTmk8XXhkps2hRvk5sGEdUu5fhbp8mZJVJj9k8JrEkzEB7nvUHF8ZjvyFcl
# NFErFzGmRzVrSvNRbs/ajaFlWhqGmKs/JJL2QvKHWifEI+4zA1YlfeRTi0h2s8S+
# k76e4dyYmIJIyPozzwSRYjO6f79aQXNdAgMBAAGjggFdMIIBWTAJBgNVHRMEAjAA
# MA4GA1UdDwEB/wQEAwIHgDArBgNVHR8EJDAiMCCgHqAchhpodHRwOi8vc3Yuc3lt
# Y2IuY29tL3N2LmNybDBhBgNVHSAEWjBYMFYGBmeBDAEEATBMMCMGCCsGAQUFBwIB
# FhdodHRwczovL2Quc3ltY2IuY29tL2NwczAlBggrBgEFBQcCAjAZDBdodHRwczov
# L2Quc3ltY2IuY29tL3JwYTATBgNVHSUEDDAKBggrBgEFBQcDAzBXBggrBgEFBQcB
# AQRLMEkwHwYIKwYBBQUHMAGGE2h0dHA6Ly9zdi5zeW1jZC5jb20wJgYIKwYBBQUH
# MAKGGmh0dHA6Ly9zdi5zeW1jYi5jb20vc3YuY3J0MB8GA1UdIwQYMBaAFJY7U/B5
# M5evfYPvLivMyreGHnJmMB0GA1UdDgQWBBRhAiqDE5/hHbTckV8t1K3VNfQsNDAN
# BgkqhkiG9w0BAQsFAAOCAQEAlemHsB2pgUA26inUeizf9LYRVw8XUKW5uHapau4A
# CM0g6IQsWgdcU4Quydh6y2/Z6B+kZZ/Rk4Pfk3/LXD+Fixi8gHoTxNYO+NbPoCEl
# wI4hxmW43LeGj7+b+QPYzE2xh/83zUtPcHdHVzk0qTeeehVPdvsXO8ujW7xqGXgR
# egNGkavY2BgXBB/KAVkVGBwApOQqDE2scgGfUP9IW8mcSPiH0z3KGHItycUDQocl
# lwLX38m00jHQChr/IFRUisJRQtfNAZ+kJEetbkTbsHE2b+CUDLEC34+b6fUpImuz
# 0SawiPfu3QXNoicsz5SxcIrgHNhX+JnFw8tfnMJMVIbmEzCCBVkwggRBoAMCAQIC
# ED141/l2SWCyYX308B7KhiowDQYJKoZIhvcNAQELBQAwgcoxCzAJBgNVBAYTAlVT
# MRcwFQYDVQQKEw5WZXJpU2lnbiwgSW5jLjEfMB0GA1UECxMWVmVyaVNpZ24gVHJ1
# c3QgTmV0d29yazE6MDgGA1UECxMxKGMpIDIwMDYgVmVyaVNpZ24sIEluYy4gLSBG
# b3IgYXV0aG9yaXplZCB1c2Ugb25seTFFMEMGA1UEAxM8VmVyaVNpZ24gQ2xhc3Mg
# MyBQdWJsaWMgUHJpbWFyeSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eSAtIEc1MB4X
# DTEzMTIxMDAwMDAwMFoXDTIzMTIwOTIzNTk1OVowfzELMAkGA1UEBhMCVVMxHTAb
# BgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8wHQYDVQQLExZTeW1hbnRlYyBU
# cnVzdCBOZXR3b3JrMTAwLgYDVQQDEydTeW1hbnRlYyBDbGFzcyAzIFNIQTI1NiBD
# b2RlIFNpZ25pbmcgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCX
# gx4AFq8ssdIIxNdok1FgHnH24ke021hNI2JqtL9aG1H3ow0Yd2i72DarLyFQ2p7z
# 518nTgvCl8gJcJOp2lwNTqQNkaC07BTOkXJULs6j20TpUhs/QTzKSuSqwOg5q1PM
# IdDMz3+b5sLMWGqCFe49Ns8cxZcHJI7xe74xLT1u3LWZQp9LYZVfHHDuF33bi+Vh
# iXjHaBuvEXgamK7EVUdT2bMy1qEORkDFl5KK0VOnmVuFNVfT6pNiYSAKxzB3JBFN
# YoO2untogjHuZcrf+dWNsjXcjCtvanJcYISc8gyUXsBWUgBIzNP4pX3eL9cT5Dio
# hNVGuBOGwhud6lo43ZvbAgMBAAGjggGDMIIBfzAvBggrBgEFBQcBAQQjMCEwHwYI
# KwYBBQUHMAGGE2h0dHA6Ly9zMi5zeW1jYi5jb20wEgYDVR0TAQH/BAgwBgEB/wIB
# ADBsBgNVHSAEZTBjMGEGC2CGSAGG+EUBBxcDMFIwJgYIKwYBBQUHAgEWGmh0dHA6
# Ly93d3cuc3ltYXV0aC5jb20vY3BzMCgGCCsGAQUFBwICMBwaGmh0dHA6Ly93d3cu
# c3ltYXV0aC5jb20vcnBhMDAGA1UdHwQpMCcwJaAjoCGGH2h0dHA6Ly9zMS5zeW1j
# Yi5jb20vcGNhMy1nNS5jcmwwHQYDVR0lBBYwFAYIKwYBBQUHAwIGCCsGAQUFBwMD
# MA4GA1UdDwEB/wQEAwIBBjApBgNVHREEIjAgpB4wHDEaMBgGA1UEAxMRU3ltYW50
# ZWNQS0ktMS01NjcwHQYDVR0OBBYEFJY7U/B5M5evfYPvLivMyreGHnJmMB8GA1Ud
# IwQYMBaAFH/TZafC3ey78DAJ80M5+gKvMzEzMA0GCSqGSIb3DQEBCwUAA4IBAQAT
# hRoeaak396C9pK9+HWFT/p2MXgymdR54FyPd/ewaA1U5+3GVx2Vap44w0kRaYdtw
# b9ohBcIuc7pJ8dGT/l3JzV4D4ImeP3Qe1/c4i6nWz7s1LzNYqJJW0chNO4LmeYQW
# /CiwsUfzHaI+7ofZpn+kVqU/rYQuKd58vKiqoz0EAeq6k6IOUCIpF0yH5DoRX9ak
# JYmbBWsvtMkBTCd7C6wZBSKgYBU/2sn7TUyP+3Jnd/0nlMe6NQ6ISf6N/SivShK9
# DbOXBd5EDBX6NisD3MFQAfGhEV0U5eK9J0tUviuEXg+mw3QFCu+Xw4kisR93873N
# Q9TxTKk/tYuEr2Ty0BQhMYIEkTCCBI0CAQEwgZMwfzELMAkGA1UEBhMCVVMxHTAb
# BgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8wHQYDVQQLExZTeW1hbnRlYyBU
# cnVzdCBOZXR3b3JrMTAwLgYDVQQDEydTeW1hbnRlYyBDbGFzcyAzIFNIQTI1NiBD
# b2RlIFNpZ25pbmcgQ0ECEFCvyjdLCeE/igXqTOR+sQUwCQYFKw4DAhoFAKCBxDAZ
# BgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYB
# BAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQURNTT46Gy9jBZaQLmfRDeFMAEalYwZAYK
# KwYBBAGCNwIBDDFWMFSgOIA2AEMAaQB0AHIAaQB4ACAAUwB1AHAAcABvAHIAdABh
# AGIAaQBsAGkAdAB5ACAAVABvAG8AbABzoRiAFmh0dHA6Ly93d3cuY2l0cml4LmNv
# bSAwDQYJKoZIhvcNAQEBBQAEggEAg2pr8YZhc436OKsZc6mhsePaMrvZsONh6NcV
# EUPbQhXAgpIiw9o+xNrlVTvtKL6Ne61zhwb3cT+qPdsQUxVjNO5zWIiWTpwTtsS6
# U9XYZhCY46xrxIp02qPjcr6reW3F6RXyhL6oQ/XGNUhct6DZMZLoqx/f9VJus9zq
# PPrSqeNpodiIR7YD3hggUzEnpq4iAMs9G9uzmeC24DlE17DsUfLKJq7rcePY74cn
# tWBMv6MLIFOGorRVrWC5CgS4VpIjB/UZ8jTWU6K1yvn94u7CYn/+zS9/4K+ryWnt
# vXEq9p6BvD/zq4RLg7yI22BXnzGVzgdLCFwIJF4mdTi6UWL/faGCAgswggIHBgkq
# hkiG9w0BCQYxggH4MIIB9AIBATByMF4xCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRT
# eW1hbnRlYyBDb3Jwb3JhdGlvbjEwMC4GA1UEAxMnU3ltYW50ZWMgVGltZSBTdGFt
# cGluZyBTZXJ2aWNlcyBDQSAtIEcyAhAOz/Q4yP6/NW4E2GqYGxpQMAkGBSsOAwIa
# BQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0x
# NzExMzAxOTU4NDBaMCMGCSqGSIb3DQEJBDEWBBR9XwiYCLJcseqWAc++6wlWhiFd
# NTANBgkqhkiG9w0BAQEFAASCAQA2SZBuQwQHx6zbZGdwQn1i+IefLuQLeYC393LM
# dyRJ0UJUqxGSTvR8HoYB5cPYZadHGQcMKdYtVRHJeKWqUX+hPY4DCc5IJVV4tkyN
# qtbsJjaaqM1fE7yZXRXj/kCrjmkWhhitVV35Z+ZJV11UNXqWCXZLMvPxyvUiv0K5
# 2fiojOzdLv6BQh+YD10/nNxu14Dqd+Ep+pKc4mFnVCFyISZOE74PbPu9IxjIdgCB
# yq9Y+hnHjFcYC9VBgF12hzTOYDcM1xCqBMTA+kYnZLXz3W5URXBi6clxOZ1mHOQn
# c/rg4X5DOMVJnnoH4KCUAUETvrRoE5CvjJRi1grSSllVBgnU
# SIG # End signature block
