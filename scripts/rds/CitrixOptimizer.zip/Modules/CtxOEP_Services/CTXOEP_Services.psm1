﻿# Function to test is service with specified name exists. 
Function Test-CTXOEServicesServiceExist ([String]$Name) {
    Return $(Get-Service -Name $Name -ErrorAction SilentlyContinue) -is [System.ServiceProcess.ServiceController]
}

# Function to test if specified service has desider startup type configured. 
Function Test-CTXOEServicesStartupType ([String]$Name, [String]$StartType) {
    [Hashtable]$Return = @{}

    $Return.Result = $False

    # Test if service exists. 
    If ($(Test-CTXOEServicesServiceExist -Name $Name) -eq $False) {
        $Return.Details = "Service $($Params.Name) was not found"
        $Return.NotFound = $true;
        $Return.Result = $StartType -eq "Disabled";
        Return $Return
    } Else {
        # If service exists, check if it is the correct startup type
        $m_Service = Get-Service -Name $Name 

        # Get the current startup type. To support Windows 7\2008 R2, using WMI instead of cmdlet
        [String]$m_CurrentStartMode = (Get-WmiObject Win32_Service -filter "Name='$Name'").StartMode

        $Return.Result = $m_CurrentStartMode -eq $StartType

        If ($m_CurrentStartMode -eq $StartType) {
            $Return.Details = "Startup type is $StartType"
        } Else {
            $Return.Details = "Desired startup type $($StartType), current type $($m_CurrentStartMode)"
        }
    }

    Return $Return
}

Function Invoke-CTXOEServicesExecuteInternal ([Xml.XmlElement]$Params, [Boolean]$RollbackSupported = $False) {
    [Hashtable]$m_Result = Test-CTXOEServicesStartupType -Name $Params.Name -StartType $Params.Value

    # If service is already configured, no action need to be taken.
    If ($m_Result.Result -eq $true) {
        $Global:CTXOE_Result = $m_Result.Result
        $Global:CTXOE_Details = $m_Result.Details
        Return
    }

    # If service was not found, return
    If ($m_Result.NotFound) {
        # If service should be disabled AND does not exists, that's OK. But if other value was configured than DISABLED, it's not OK. 
        $Global:CTXOE_Result = $Params.Value -eq "Disabled"
        $Global:CTXOE_Details = "Service $($Params.Name) was not found"
        Return
    } Else {
        # Save the current startup mode. 
        [String]$m_PreviousStartMode = (Get-WmiObject Win32_Service -filter "Name='$($Params.Name)'").StartMode

        # Set service to required type, re-run the test for startup type
        If ($Params.Value -eq "Auto") { # WMI is using 'Auto', Set-Service is using "Automatic"
            Set-Service -Name $Params.Name -StartupType Automatic
        } Else {
            Set-Service -Name $Params.Name -StartupType $Params.Value
        }

        # Same the last known startup type for rollback instructions
        $Global:CTXOE_SystemChanged = $true;
        If ($RollbackSupported) {
            [Xml.XmlDocument]$m_RollbackElement = CTXOE\ConvertTo-CTXOERollbackElement -Element $Params
            $m_RollbackElement.rollbackparams.value = $m_PreviousStartMode.ToString();
            $Global:CTXOE_ChangeRollbackParams = $m_RollbackElement
        }

        [Hashtable]$m_Result = Test-CTXOEServicesStartupType -Name $Params.Name -StartType $Params.Value
        $Global:CTXOE_Result = $m_Result.Result
        $Global:CTXOE_Details = $m_Result.Details
    }

    Return
}

Function Invoke-CTXOEServicesAnalyze ([Xml.XmlElement]$Params) {
    [Hashtable]$m_Result = Test-CTXOEServicesStartupType -Name $Params.Name -StartType $Params.Value

    $Global:CTXOE_Result = $m_Result.Result
    $Global:CTXOE_Details = $m_Result.Details

    Return

}

Function Invoke-CTXOEServicesExecute ([Xml.XmlElement]$Params) {
    Invoke-CTXOEServicesExecuteInternal -Params $Params -RollbackSupported $True
}

Function Invoke-CTXOEServicesRollback ([Xml.XmlElement]$Params) {
    Invoke-CTXOEServicesExecuteInternal -Params $Params -RollbackSupported $False
}
# SIG # Begin signature block
# MIIYIAYJKoZIhvcNAQcCoIIYETCCGA0CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUKXf9olD7AoRfIMW03g13McXz
# Zz6gghL5MIID7jCCA1egAwIBAgIQfpPr+3zGTlnqS5p31Ab8OzANBgkqhkiG9w0B
# AQUFADCBizELMAkGA1UEBhMCWkExFTATBgNVBAgTDFdlc3Rlcm4gQ2FwZTEUMBIG
# A1UEBxMLRHVyYmFudmlsbGUxDzANBgNVBAoTBlRoYXd0ZTEdMBsGA1UECxMUVGhh
# d3RlIENlcnRpZmljYXRpb24xHzAdBgNVBAMTFlRoYXd0ZSBUaW1lc3RhbXBpbmcg
# Q0EwHhcNMTIxMjIxMDAwMDAwWhcNMjAxMjMwMjM1OTU5WjBeMQswCQYDVQQGEwJV
# UzEdMBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xMDAuBgNVBAMTJ1N5bWFu
# dGVjIFRpbWUgU3RhbXBpbmcgU2VydmljZXMgQ0EgLSBHMjCCASIwDQYJKoZIhvcN
# AQEBBQADggEPADCCAQoCggEBALGss0lUS5ccEgrYJXmRIlcqb9y4JsRDc2vCvy5Q
# WvsUwnaOQwElQ7Sh4kX06Ld7w3TMIte0lAAC903tv7S3RCRrzV9FO9FEzkMScxeC
# i2m0K8uZHqxyGyZNcR+xMd37UWECU6aq9UksBXhFpS+JzueZ5/6M4lc/PcaS3Er4
# ezPkeQr78HWIQZz/xQNRmarXbJ+TaYdlKYOFwmAUxMjJOxTawIHwHw103pIiq8r3
# +3R8J+b3Sht/p8OeLa6K6qbmqicWfWH3mHERvOJQoUvlXfrlDqcsn6plINPYlujI
# fKVOSET/GeJEB5IL12iEgF1qeGRFzWBGflTBE3zFefHJwXECAwEAAaOB+jCB9zAd
# BgNVHQ4EFgQUX5r1blzMzHSa1N197z/b7EyALt0wMgYIKwYBBQUHAQEEJjAkMCIG
# CCsGAQUFBzABhhZodHRwOi8vb2NzcC50aGF3dGUuY29tMBIGA1UdEwEB/wQIMAYB
# Af8CAQAwPwYDVR0fBDgwNjA0oDKgMIYuaHR0cDovL2NybC50aGF3dGUuY29tL1Ro
# YXd0ZVRpbWVzdGFtcGluZ0NBLmNybDATBgNVHSUEDDAKBggrBgEFBQcDCDAOBgNV
# HQ8BAf8EBAMCAQYwKAYDVR0RBCEwH6QdMBsxGTAXBgNVBAMTEFRpbWVTdGFtcC0y
# MDQ4LTEwDQYJKoZIhvcNAQEFBQADgYEAAwmbj3nvf1kwqu9otfrjCR27T4IGXTdf
# plKfFo3qHJIJRG71betYfDDo+WmNI3MLEm9Hqa45EfgqsZuwGsOO61mWAK3ODE2y
# 0DGmCFwqevzieh1XTKhlGOl5QGIllm7HxzdqgyEIjkHq3dlXPx13SYcqFgZepjhq
# IhKjURmDfrYwggSjMIIDi6ADAgECAhAOz/Q4yP6/NW4E2GqYGxpQMA0GCSqGSIb3
# DQEBBQUAMF4xCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRTeW1hbnRlYyBDb3Jwb3Jh
# dGlvbjEwMC4GA1UEAxMnU3ltYW50ZWMgVGltZSBTdGFtcGluZyBTZXJ2aWNlcyBD
# QSAtIEcyMB4XDTEyMTAxODAwMDAwMFoXDTIwMTIyOTIzNTk1OVowYjELMAkGA1UE
# BhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMTQwMgYDVQQDEytT
# eW1hbnRlYyBUaW1lIFN0YW1waW5nIFNlcnZpY2VzIFNpZ25lciAtIEc0MIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAomMLOUS4uyOnREm7Dv+h8GEKU5Ow
# mNutLA9KxW7/hjxTVQ8VzgQ/K/2plpbZvmF5C1vJTIZ25eBDSyKV7sIrQ8Gf2Gi0
# jkBP7oU4uRHFI/JkWPAVMm9OV6GuiKQC1yoezUvh3WPVF4kyW7BemVqonShQDhfu
# ltthO0VRHc8SVguSR/yrrvZmPUescHLnkudfzRC5xINklBm9JYDh6NIipdC6Anqh
# d5NbZcPuF3S8QYYq3AhMjJKMkS2ed0QfaNaodHfbDlsyi1aLM73ZY8hJnTrFxeoz
# C9Lxoxv0i77Zs1eLO94Ep3oisiSuLsdwxb5OgyYI+wu9qU+ZCOEQKHKqzQIDAQAB
# o4IBVzCCAVMwDAYDVR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDAO
# BgNVHQ8BAf8EBAMCB4AwcwYIKwYBBQUHAQEEZzBlMCoGCCsGAQUFBzABhh5odHRw
# Oi8vdHMtb2NzcC53cy5zeW1hbnRlYy5jb20wNwYIKwYBBQUHMAKGK2h0dHA6Ly90
# cy1haWEud3Muc3ltYW50ZWMuY29tL3Rzcy1jYS1nMi5jZXIwPAYDVR0fBDUwMzAx
# oC+gLYYraHR0cDovL3RzLWNybC53cy5zeW1hbnRlYy5jb20vdHNzLWNhLWcyLmNy
# bDAoBgNVHREEITAfpB0wGzEZMBcGA1UEAxMQVGltZVN0YW1wLTIwNDgtMjAdBgNV
# HQ4EFgQURsZpow5KFB7VTNpSYxc/Xja8DeYwHwYDVR0jBBgwFoAUX5r1blzMzHSa
# 1N197z/b7EyALt0wDQYJKoZIhvcNAQEFBQADggEBAHg7tJEqAEzwj2IwN3ijhCcH
# bxiy3iXcoNSUA6qGTiWfmkADHN3O43nLIWgG2rYytG2/9CwmYzPkSWRtDebDZw73
# BaQ1bHyJFsbpst+y6d0gxnEPzZV03LZc3r03H0N45ni1zSgEIKOq8UvEiCmRDoDR
# EfzdXHZuT14ORUZBbg2w6jiasTraCXEQ/Bx5tIB7rGn0/Zy2DBYr8X9bCT2bW+IW
# yhOBbQAuOA2oKY8s4bL0WqkBrxWcLC9JG9siu8P+eJRRw4axgohd8D20UaF5Mysu
# e7ncIAkTcetqGVvP6KUwVyyJST+5z3/Jvz4iaGNTmr1pdKzFHTx/kuDDvBzYBHUw
# ggT/MIID56ADAgECAhBQr8o3SwnhP4oF6kzkfrEFMA0GCSqGSIb3DQEBCwUAMH8x
# CzAJBgNVBAYTAlVTMR0wGwYDVQQKExRTeW1hbnRlYyBDb3Jwb3JhdGlvbjEfMB0G
# A1UECxMWU3ltYW50ZWMgVHJ1c3QgTmV0d29yazEwMC4GA1UEAxMnU3ltYW50ZWMg
# Q2xhc3MgMyBTSEEyNTYgQ29kZSBTaWduaW5nIENBMB4XDTE3MDEzMTAwMDAwMFoX
# DTE4MDEzMTIzNTk1OVowgZYxCzAJBgNVBAYTAlVTMRAwDgYDVQQIDAdGbG9yaWRh
# MRgwFgYDVQQHDA9Gb3J0IExhdWRlcmRhbGUxHTAbBgNVBAoMFENpdHJpeCBTeXN0
# ZW1zLCBJbmMuMR0wGwYDVQQLDBRYZW5BcHAoU2VydmVyU0hBMjU2KTEdMBsGA1UE
# AwwUQ2l0cml4IFN5c3RlbXMsIEluYy4wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
# ggEKAoIBAQDtkgVPpUMSAQNv0qsiKSRSC4gZgbZS6sbGxwH9IWFTZ37YbkVju16a
# elVVvCjfwjvsVjWXDiSaqKHiZyiBnbPZhsvmEMfYit5EfzxEBt+rpmJMLCbkTfOr
# GmuMSVl6VFgu8fcr/ZSBTeCf64OBt8QGJJpDt1L3zCGdgGg82sViDkzLCpxafei7
# GdXpUVTmk8XXhkps2hRvk5sGEdUu5fhbp8mZJVJj9k8JrEkzEB7nvUHF8ZjvyFcl
# NFErFzGmRzVrSvNRbs/ajaFlWhqGmKs/JJL2QvKHWifEI+4zA1YlfeRTi0h2s8S+
# k76e4dyYmIJIyPozzwSRYjO6f79aQXNdAgMBAAGjggFdMIIBWTAJBgNVHRMEAjAA
# MA4GA1UdDwEB/wQEAwIHgDArBgNVHR8EJDAiMCCgHqAchhpodHRwOi8vc3Yuc3lt
# Y2IuY29tL3N2LmNybDBhBgNVHSAEWjBYMFYGBmeBDAEEATBMMCMGCCsGAQUFBwIB
# FhdodHRwczovL2Quc3ltY2IuY29tL2NwczAlBggrBgEFBQcCAjAZDBdodHRwczov
# L2Quc3ltY2IuY29tL3JwYTATBgNVHSUEDDAKBggrBgEFBQcDAzBXBggrBgEFBQcB
# AQRLMEkwHwYIKwYBBQUHMAGGE2h0dHA6Ly9zdi5zeW1jZC5jb20wJgYIKwYBBQUH
# MAKGGmh0dHA6Ly9zdi5zeW1jYi5jb20vc3YuY3J0MB8GA1UdIwQYMBaAFJY7U/B5
# M5evfYPvLivMyreGHnJmMB0GA1UdDgQWBBRhAiqDE5/hHbTckV8t1K3VNfQsNDAN
# BgkqhkiG9w0BAQsFAAOCAQEAlemHsB2pgUA26inUeizf9LYRVw8XUKW5uHapau4A
# CM0g6IQsWgdcU4Quydh6y2/Z6B+kZZ/Rk4Pfk3/LXD+Fixi8gHoTxNYO+NbPoCEl
# wI4hxmW43LeGj7+b+QPYzE2xh/83zUtPcHdHVzk0qTeeehVPdvsXO8ujW7xqGXgR
# egNGkavY2BgXBB/KAVkVGBwApOQqDE2scgGfUP9IW8mcSPiH0z3KGHItycUDQocl
# lwLX38m00jHQChr/IFRUisJRQtfNAZ+kJEetbkTbsHE2b+CUDLEC34+b6fUpImuz
# 0SawiPfu3QXNoicsz5SxcIrgHNhX+JnFw8tfnMJMVIbmEzCCBVkwggRBoAMCAQIC
# ED141/l2SWCyYX308B7KhiowDQYJKoZIhvcNAQELBQAwgcoxCzAJBgNVBAYTAlVT
# MRcwFQYDVQQKEw5WZXJpU2lnbiwgSW5jLjEfMB0GA1UECxMWVmVyaVNpZ24gVHJ1
# c3QgTmV0d29yazE6MDgGA1UECxMxKGMpIDIwMDYgVmVyaVNpZ24sIEluYy4gLSBG
# b3IgYXV0aG9yaXplZCB1c2Ugb25seTFFMEMGA1UEAxM8VmVyaVNpZ24gQ2xhc3Mg
# MyBQdWJsaWMgUHJpbWFyeSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eSAtIEc1MB4X
# DTEzMTIxMDAwMDAwMFoXDTIzMTIwOTIzNTk1OVowfzELMAkGA1UEBhMCVVMxHTAb
# BgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8wHQYDVQQLExZTeW1hbnRlYyBU
# cnVzdCBOZXR3b3JrMTAwLgYDVQQDEydTeW1hbnRlYyBDbGFzcyAzIFNIQTI1NiBD
# b2RlIFNpZ25pbmcgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCX
# gx4AFq8ssdIIxNdok1FgHnH24ke021hNI2JqtL9aG1H3ow0Yd2i72DarLyFQ2p7z
# 518nTgvCl8gJcJOp2lwNTqQNkaC07BTOkXJULs6j20TpUhs/QTzKSuSqwOg5q1PM
# IdDMz3+b5sLMWGqCFe49Ns8cxZcHJI7xe74xLT1u3LWZQp9LYZVfHHDuF33bi+Vh
# iXjHaBuvEXgamK7EVUdT2bMy1qEORkDFl5KK0VOnmVuFNVfT6pNiYSAKxzB3JBFN
# YoO2untogjHuZcrf+dWNsjXcjCtvanJcYISc8gyUXsBWUgBIzNP4pX3eL9cT5Dio
# hNVGuBOGwhud6lo43ZvbAgMBAAGjggGDMIIBfzAvBggrBgEFBQcBAQQjMCEwHwYI
# KwYBBQUHMAGGE2h0dHA6Ly9zMi5zeW1jYi5jb20wEgYDVR0TAQH/BAgwBgEB/wIB
# ADBsBgNVHSAEZTBjMGEGC2CGSAGG+EUBBxcDMFIwJgYIKwYBBQUHAgEWGmh0dHA6
# Ly93d3cuc3ltYXV0aC5jb20vY3BzMCgGCCsGAQUFBwICMBwaGmh0dHA6Ly93d3cu
# c3ltYXV0aC5jb20vcnBhMDAGA1UdHwQpMCcwJaAjoCGGH2h0dHA6Ly9zMS5zeW1j
# Yi5jb20vcGNhMy1nNS5jcmwwHQYDVR0lBBYwFAYIKwYBBQUHAwIGCCsGAQUFBwMD
# MA4GA1UdDwEB/wQEAwIBBjApBgNVHREEIjAgpB4wHDEaMBgGA1UEAxMRU3ltYW50
# ZWNQS0ktMS01NjcwHQYDVR0OBBYEFJY7U/B5M5evfYPvLivMyreGHnJmMB8GA1Ud
# IwQYMBaAFH/TZafC3ey78DAJ80M5+gKvMzEzMA0GCSqGSIb3DQEBCwUAA4IBAQAT
# hRoeaak396C9pK9+HWFT/p2MXgymdR54FyPd/ewaA1U5+3GVx2Vap44w0kRaYdtw
# b9ohBcIuc7pJ8dGT/l3JzV4D4ImeP3Qe1/c4i6nWz7s1LzNYqJJW0chNO4LmeYQW
# /CiwsUfzHaI+7ofZpn+kVqU/rYQuKd58vKiqoz0EAeq6k6IOUCIpF0yH5DoRX9ak
# JYmbBWsvtMkBTCd7C6wZBSKgYBU/2sn7TUyP+3Jnd/0nlMe6NQ6ISf6N/SivShK9
# DbOXBd5EDBX6NisD3MFQAfGhEV0U5eK9J0tUviuEXg+mw3QFCu+Xw4kisR93873N
# Q9TxTKk/tYuEr2Ty0BQhMYIEkTCCBI0CAQEwgZMwfzELMAkGA1UEBhMCVVMxHTAb
# BgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8wHQYDVQQLExZTeW1hbnRlYyBU
# cnVzdCBOZXR3b3JrMTAwLgYDVQQDEydTeW1hbnRlYyBDbGFzcyAzIFNIQTI1NiBD
# b2RlIFNpZ25pbmcgQ0ECEFCvyjdLCeE/igXqTOR+sQUwCQYFKw4DAhoFAKCBxDAZ
# BgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYB
# BAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUvvulKtF5hy0Dq2zwQXNumRwC1t0wZAYK
# KwYBBAGCNwIBDDFWMFSgOIA2AEMAaQB0AHIAaQB4ACAAUwB1AHAAcABvAHIAdABh
# AGIAaQBsAGkAdAB5ACAAVABvAG8AbABzoRiAFmh0dHA6Ly93d3cuY2l0cml4LmNv
# bSAwDQYJKoZIhvcNAQEBBQAEggEAcsgoifK2ZEen3pDg2mNIyVADf79lnVM/94L2
# 4xmhAKzCfvwAPF2O1x2gbqtx7vtfVSSsqbqQvcWwKsEByG0RdFhfYFY8dXBu9Myd
# ilabnlaJ5vrQTnRTGWjTNG/ob3aX0QSdzcRiW54HPG2PjQvJWU+1IJ7U13gpq8zm
# t292rUihpHFKVZc2BbDdoz7OF9q1WJt6ad8msRXHqeAC3vkqwvukwVNNmELLJRGM
# 1TfTsYa6d8vkFLdE3SMIe820HaPap6p1KAoA7WUY+OV7PkzQ/KRbiE+qGmYUp7SB
# RbRPhTlOA6lRYLLqryTUFIELLsywaInty1yHaXCu5n2vRj3dj6GCAgswggIHBgkq
# hkiG9w0BCQYxggH4MIIB9AIBATByMF4xCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRT
# eW1hbnRlYyBDb3Jwb3JhdGlvbjEwMC4GA1UEAxMnU3ltYW50ZWMgVGltZSBTdGFt
# cGluZyBTZXJ2aWNlcyBDQSAtIEcyAhAOz/Q4yP6/NW4E2GqYGxpQMAkGBSsOAwIa
# BQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0x
# NzExMzAxOTU4NDBaMCMGCSqGSIb3DQEJBDEWBBSHGLmWAKfm5N/RJnDzrON25C8n
# HzANBgkqhkiG9w0BAQEFAASCAQBollWHMcTpLHtya+dETA1QBmINo4b1YykUuaWg
# MdZvc/CiNu36IvNNHxG0FZ9wdV1KpMiD+GFHxqoZmn01ZUP01uQ6bP2n44/wBCUl
# vtyX7EQ6QZw5g5Vt8h4KXs1U2iykT5sfV+Uko8EsGid/22Tf9BtSqGI6rJG8h560
# caWXjlGd6EGS1b+mjZip7tHcXM2OAE4VRFuMxCv3XXzTAP/2FI6oINybL5gDucn8
# OJjz919rdAoKb3cZAr+eLJl4tfsc2ukePi27Wk4yR67j8D1GOrvzTb2p591dqQ7u
# eDzzNMmvIeFJct+TSIaaIsfPiIVk678kOxlwqCl9GNEeuU0L
# SIG # End signature block
