#   Windows 10 Set-Customisations.ps1

Set-MpPreference -PUAProtection Enabled
